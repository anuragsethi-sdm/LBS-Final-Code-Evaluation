
1.Project Overview:
.In this project I create sentiment Analysis of Product Review App, where user enter the review . we show that review is positive , negative or neural.
.This is the concept of NLP(Natural Language Process)
.In this project I work on two columns only which is reviewText or overall
.with the lost of steps we clean the datasets
.here I use tokenization,lemmatization concept which is comes under the NLP
.Lastly I deploy on streamlit platform
--------------------------------------------------------------------------------------------------------------------------
2.folder Structure:
sentiment_analysis.ipynb
sentiment.py
tfidf.pkl
senti.pkl
-----------------------------------------------------------------------------------------------------------------
3.Libraries & Environment Setup:
 .pandas
 .sklearn
 .linear_model
 .metrics
 .nltk
 .re
-----------------------------------------------------------------------------------------------------------------------
4.run via streamlite
.command is--->streamlit run sentiment.py

------------------------------------------------------------------------------------------------------------------------
5.Input & Output Explanation

.Input-->Enter your review here,this expects only text format
.Output-->predict, result will be show as a positive,negative,neural
------------------------------------------------------------------------------------------------------------------------